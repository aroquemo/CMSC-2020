
import java.util.Scanner;
public class RandomNumberGuesser {

	public static void main(String[] args) {
		
		// Variab;es
		
	
	int nextGuess;
	
	int lowest = 1;
	
	int highest = 100;
	
		//Scanner input
	Scanner userInput = new Scanner(System.in);
	
	// String literals
	String answer;

	
	// Beginning of first do-while statement
	do {
		
	//Beginning of second do-while statement	
		
		do {

			// Introduction to Random number generator, list number of guess, and ask for first guess
		System.out.println("RANDOM NUMBER GENERATOR!");
		
		System.out.println("Number of guesses is " + RNG.getCount());
		
		System.out.println("Enter guess here: ");
		
		nextGuess = userInput.nextInt();
		
		
		// Calls for getter inputValidation, and determines user highest/lowest guess and if they surpass scale(1-100)

		System.out.println(RNG.inputValidation(nextGuess, lowest, highest));
		
		
		// If statement to determine if nextGuess is correct to Random number generated
		
		if( nextGuess == RNG.rand() ) {
			
			System.out.println("That is correct! Do you want to play again?(y or n)");
			answer = userInput.next();
			
		}
		
	// If user stays with 1-100, code will move on to tell them incorrect
		
		else {
			
			System.out.println("That is incorrect. Try again!\n Enter next guess here: ");
		userInput.nextInt();
		
		// Keeps track of number of guesses
		System.out.println("Number of guesses is " + RNG.getCount());
		
		
		}
		
		
		// Calls for getter inputValidation, and determines user highest/lowest guess and if they surpass scale(1-100)
		System.out.println(RNG.inputValidation(nextGuess, lowest, highest));

		// If statement to determine if nextGuess is correct to Random number generated
		
		if( nextGuess == RNG.rand() ) {
			
			System.out.println("That is correct! Do you want to play again?(y or n)");
			answer = userInput.next();
			
		}
		
		// If user stays with 1-100, code will move on to tell them incorrect
		else {
			
			System.out.println("That is incorrect. Try again!\n Enter next guess here: ");
		userInput.nextInt();
		
		}
		
		// Keeps track of number of guesses
		System.out.println("Number of guesses is " + RNG.getCount());
		
		// Calls for getter inputValidation, and determines user highest/lowest guess and if they surpass scale(1-100)
		System.out.println(RNG.inputValidation(nextGuess, lowest, highest));
		
		// If statement to determine if nextGuess is correct to Random number generated		
		
if( nextGuess == RNG.rand() ) {
	
	System.out.println("That is correct! Do you want to play again?(y or n)");
	answer = userInput.next();
	
}
//If user stays with 1-100, code will move on to tell them incorrect
else {
	
	System.out.println("That is incorrect.  ");
	
	System.out.println("The correct number was " + RNG.rand() + "\n Would you like to play again?(y or n): ");
	answer =  userInput.next();

}
	}
	while(answer.equals("y")); // End of second do-while statement
		
		
	
		
	
	
	
	
	
	
	
	
	
	}
	while(answer.equals("y")); // End of first do-while statement

	}
}
