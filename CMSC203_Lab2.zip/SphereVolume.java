import java.util.Scanner;

/**Pseudo-code for SphereVolume.java: 
Print the purpose of the program 
Print a prompt asking for the diameter of a sphere 
Read the diameter 
Calculate the radius as diameter divided by 2 
Calculate volume of the sphere using the formula (see Task #3b) 

*/



public class SphereVolume {

		public static void main(String[] args) {
			
			// define variables
			double diam, radius, volume;
			Scanner scan = new Scanner(System.in);
			
			// Print header of program
			System.out.println("Volume of the Sphere Calculator");
			
			// Calculate the radius as diameter divided by 2 
			System.out.print("Please enter the diameter of the sphere: ");
			diam = scan.nextDouble();
			radius = diam/2;
			
			// Calculate volume of the sphere using the formula (see Task #3b)
			volume = (4 * Math.PI / 3) * Math.pow(radius, 3);	
			System.out.println("The volume of the sphere with diameter " + diam + " is " + volume);
			
			scan.close();
		}

	}