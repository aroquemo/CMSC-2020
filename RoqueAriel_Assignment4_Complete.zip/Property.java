package application;

// Programmer: Ariel Roque
// CMSC 203
// Assignment 4

// Variables for #1 of element class Property

public class Property {

private double rentAmount;

private Plot plot;

private String city;

private String owner;

private String propertyName;



// Sets property 

	public Property() 
	{
		owner = "";
		
		propertyName = "";
		
		city = "";
		
		rentAmount = 0;
		
		plot = new Plot(0,0,1,1);
	}
	
	
	// Identifies property name, owner, property name, rent amount, and plots.
	
	public Property(Property x)
	
	{
		
		owner=x.getOwner();
		
		propertyName=x.getPropertyName();
		
		city=x.getCity();
		
		rentAmount=x.getRentAmount();
		
		plot= new Plot(x.plot);
		
		
	}
	
	// Sets property name, city, rent amount, and owner to input
	
	public Property (String propName, String city, double rentAmount, String owner)
	
	{
		
		this.rentAmount= rentAmount;
		
		this.owner=owner;
		
		this.propertyName= propName;
		
		this.city= city;
		
		plot = new Plot();
	}
	
	// Sets Property name, city, rent amount, owner, integers x, y, width, depth to "this." input
	
	public Property (String propName, String city, double rentAmount, String owner, int x, int y, int width, int depth) 
	
	{
		this.city= city;
		
		this.rentAmount= rentAmount;
		
		this.propertyName= propName;
		
		this.owner=owner;
		
		plot= new Plot(x,y,width,depth);
	}
	
	
	// (3) Element Property setters and getter methods below
	
	public double getRentAmount() 
	{
		
		return rentAmount;
		
	}

	
	
	public String getOwner()
	{
		
		return owner;
		
	}


	public String getPropertyName() 
	{
	
		return propertyName;
		
	}
	
	public String getCity()
	{
		
		return city;
		
	}
	
	
	

	public Plot getPlot()
	{
		
		return plot;
		
	}
	
	public void setRentAmount(double rentAmount)
	{
		
		this.rentAmount=rentAmount;
		
	}
	
	
	public void setOwner (String owner) 
	{
		
		this.owner=owner;
		
	}
	
	public void setCity (String city)
	{
		
		this.city=city;
		
	}
	
	
	
	public void setPropertyName (String propertyName)
	{
		
		this.propertyName=propertyName;
		
	}
	

	
	public Plot setPlot(int x, int y, int width, int depth) 
	{
		
		plot = new Plot(x,y,width,depth);
		return plot;
		
		
	}
	
	@Override
	
	// ToString for element class property(2)
	
	public String toString() 
	{
		String get = "Property Name: "+propertyName
	               +"\nLocated in "+city
	               +"\nBelonging to: "+ owner
	               +"\nRent Amount: "+rentAmount+"\n";
		return get;
	}
	
}