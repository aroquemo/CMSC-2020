//Assignment 1 by Ariel Roque-Morales

import java.util.Scanner;


public class wifiDiagnosis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// String word that way change
		String response;
		
		//Gives access to hold response
		Scanner keyboard = new Scanner (System.in);
		
		
		// Stating the purpose of the test the user will run
		System.out.println("Having trouble with your wifi? Try this Wifi Diagnosis test!(Please use yes or no for your response)\n\n");
		
		
		// First step
	System.out.println("Let's try this first, have you tried rebooting your computer?: \n\n");
	
	response = keyboard.nextLine();

	
	// Verifying their response to see which outcome to print out
	switch(response)
{
	case "no":
		System.out.println("Now checking connection\n=========================================================\n\n");
		
		System.out.println("Did that fix your probelm?: ");
		
		keyboard.nextLine();
		break;
	case "yes":
		System.out.println("Did that fix your probelm?: ");
		
		keyboard.nextLine();
		break;
}
	
	

	
	// Solution 2
	System.out.println("\nHave you tried rebooting your router?: ");
	
	keyboard.nextLine();
	
	// Verifying their response to see which outcome to print out
	switch (response)
	{
	case "no":
		System.out.println("Now checking connection\n=========================================================\n\n");
		
		System.out.println("Did that fix your probelm?: ");
		
		keyboard.nextLine();
		break;
	case "yes":
		System.out.println("Did that fix your probelm?: ");
		
		keyboard.nextLine();
		
		break;	
		
	}
	
	
	//Solution 3
	System.out.println("\nHave you made sure all your wifi settings were correct?: ");
	
	keyboard.nextLine();
	
	// Verifying their response to see which outcome to print out
	switch (response)
	{
	case "no":
		System.out.println("Now checking connection\n=========================================================\n\n");
		
		
		System.out.println("Did that fix your probelm?: ");
		
		keyboard.nextLine();
		
		break;
	case "yes":
		System.out.println("Did that fix your probelm?: ");
		
		keyboard.nextLine();
		break;	
		
	}

	
	
	// Solution 4
	System.out.println("\nHave you tried using a ethernet cable?: ");
	keyboard.nextLine();
	
	// Verifying their response to see which outcome to print out
	switch (response)
	{
	case "no":
		System.out.println("Now checking connection\n=========================================================\n\n");
		
		
		System.out.println("Did that fix your probelm?: ");
		
		keyboard.nextLine();
		break;	
	}

	
	// If none of the solutions work, this is the users best option
	System.out.println("It may be best for you to contact your internet provider.");
	
	}

}
