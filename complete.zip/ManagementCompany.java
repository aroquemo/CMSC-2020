package application;



import java.text.DecimalFormat;

public class ManagementCompany {
	
	// Variables
	
	private String name;
	
	private String taxID;
	
	private double managemnetFee;
	
	private final int MAX_PROPERTY=5;
	
	
	private Property[] properties = new Property [MAX_PROPERTY];
	
	private final int MGMT_WIDTH=10;
	
	private final int MGMT_DEPTH=10;
	
	private Plot plot;
	
	private int index;
	
	
	// Sets Name, taxID, plot to default/blank
	
	public ManagementCompany() 
	
	{
		name = "";
		
		taxID = "";
		
		plot = new Plot (0, 0, MGMT_WIDTH, MGMT_DEPTH);
		
		properties = new Property[MAX_PROPERTY];
		
		index = 0;
	}
	
	
	
	public ManagementCompany(String name, String taxID, double fee) {
		this.name=name;
		
		this.taxID = taxID;
		
		this.managemnetFee = fee;
		
		plot= new Plot (0,0,MGMT_WIDTH, MGMT_DEPTH);
		
		properties= new Property[MAX_PROPERTY];
		
		index=0;
	}

	// Sets name, TaxID, fee, integers x, y, width, and depth equal to parameters
	
	public ManagementCompany(String name, String taxID, double fee, int x, int y, int width, int depth ) {
		this.name = name;
		
		this.taxID = taxID;
		
		this.managemnetFee = fee;
		
		plot = new Plot (x, y, width, depth);
		
		properties = new Property[MAX_PROPERTY];
		
		index = 0;
	}
	
	
	// Sets name, TaxID, fee, plot equal to other company inputs
	
	public ManagementCompany(ManagementCompany otherCompany)

	{
		this.name = otherCompany.name;
		
		this.taxID = otherCompany.taxID;
		
		this.managemnetFee = otherCompany.managemnetFee;
		
		this.plot = otherCompany.plot;
		
		properties = new Property[MAX_PROPERTY];
		
		index=0;
	}

	
	
	// Returns Max Property
	
	public int getMAX_PROPERTY()

	{
	
		return MAX_PROPERTY;
		
	}

	
	// First addProperty
	
	public int addProperty(Property property) 
	{

		if(property == null)
			
			return -2;
		
		if(index >= MAX_PROPERTY)
			
			return -1;
		
		for(int i= 0; i<index;i++) {
			if(property.getPlot().overlaps(properties[i].getPlot()))
					return -4;
		}
		
		properties[index]= property;
		
		index++;
		
		return index-1;
		
	}
	
	
	// second addProperty

	public int addProperty(String name,String city,double rent,String owner) {
		Property property= new Property(name, city, rent, owner);
		
		if(index >=5 )
			
			return -1;
		
		if(!plot.encompasses(property.getPlot()))
			
			return -3;
		
		for(int i= 0; i<index;i++) 
		{
			
			if(property.getPlot().overlaps(properties[i].getPlot()))
				
					return -4;
		}
		
		properties[index]= property;
		
		index++;
		
		return index-1;
	}
	
	
	// Last addProperty
	
	public int addProperty(String name,String city,double rent,String owner,int x,int y,int width,int depth) {
		Property property = new Property(name, city, rent, owner, x, y, width, depth);
		
		if(index >= 5)
			
			return -1;
		
		if(!plot.encompasses(property.getPlot()))
			
			return -3;
		
		for(int i = 0; i < index; i++) 
		{
			if(property.getPlot().overlaps(properties[i].getPlot()))
				
					return -4;
		}
		
		properties [index]= property;
		
		index++;
		
		return index-1;
	}
	
	
// Returns Max Rent Amount	
	
	public String maxRentProp()
	{
		
		String maxRent = properties[maxRentPropertyIndex()].toString();
		
		return maxRent;
		
	}
	
	// Returns Max rent property
	
		public double maxRentProperty()
		{
			
			return properties[maxRentPropertyIndex()].getRentAmount();
			
		}
	
	// Returns total rent amount
	
	public double totalRent() 
	{
		double totalRent=0;
		
		for (int i=0; i<index; i++)
		{
			
			totalRent+= properties[i].getRentAmount();
			
		}
		return totalRent;
	}
	
	// Max Rent property, returns maxIndex
	
	public int maxRentPropertyIndex() 
	
	{
		int maxIndex = 0;
		
		double maxRent = properties[0].getRentAmount();
		
		for (int x=0; x < index; x++) 
		{
			
		if (properties[x].getRentAmount()> maxRent)
			{
			maxIndex= x;
			maxRent = properties[x].getRentAmount();
			}
		}
		return maxIndex;
	}
	
	
	// Displays properties
	
	public String displayPropertyAtIndex(int d) 
	
	{
		String display = properties[d].toString();
		return display;
	}
	
	
	// Sets name
	
	public void setName(String name)
	{
		
		this.name = name;
		
	}
	
	// Get name
	
	public String getName()
	{
		
		return name;
		
	}
	
	
// Set plot
	
 void setPlot(int x, int y, int width, int depth) 
	 
	 {
		 
		plot = new Plot (x,y,width,depth);
		
	}
	
	
	
	// Get plot
	
	public Plot getPlot() 
	
	{
		return plot;
	}
	
	// To string to display all info
	
	
	
	public String toString() 
	{
		String get;
		
		String propertyInfo = "";
		
		double m = (managemnetFee / 100) * totalRent();
		
		for(int x = 0; x < index ; x++) 
		{
			
			propertyInfo+=displayPropertyAtIndex(x);
			
		}
		get = "List of all properties for "+ name +", taxID: " + taxID 
				+"\n_____________________________________\n"
				+propertyInfo
				+"_____________________________________\ntotal management Fee: " + m ;
		
		return get;
	}
}