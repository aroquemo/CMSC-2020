package application;

//Programmer: Ariel Roque
//CMSC 203
//Assignment 4

public class Plot {
	
	private int x;
	
	private int y;
	
	private int width;
	
	private int depth;

	
	// Sets plots

		public Plot () 
		{
			x = 0;
			
			y = 0;
			
			width = 1;
			
			depth = 1;
			
		}
		
		// Verify overlap of plot a

		public Plot (Plot a) 
		
		{
			x = a.x;
			
			y = a.y;
			
			width = a.width;
			
			depth = a.depth;
		}
		
		
		// Plot with parameter integers x, y, width, depth
		
		public Plot(int x, int y, int width, int depth) 
		{
			this.x = x;
			
			this.y = y;
			
			this.width = width;
			
			this.depth = depth;
		}
		

		// Verify overlap of plot b
		
		public boolean overlaps(Plot b) 
		{
			if(b.x >= (x + width) || (b.x + b.width) <= x)
				
				return false;
			
			if(b.y >=(y+depth)|| (b.y + b.depth) <= y)
				
				return false;
			
			return true;
		}
		
		
		
		public boolean encompasses (Plot c) {
		
			boolean a;
			
			boolean b;
			
			boolean w;
			
			boolean d;
			
			if(x <= c.x)
				
			a = true;
			
			else a = false;
			if(y <= c.y)
				
				b = true;
			
			else b = false;
			
			if( (width+x) >= (c.width + c.x) )
				
				w = true;
			
			else d= false;
			
			if( (depth+y) >= (c.depth + c.y) )
				
				d = true;
			
			else d = false;
			
			return  a && b && d;
			
		}
	
		
		// Setters and getters
		
		
		
	// Set X in order to get X
		
		public void setX(int x) 
		
		{
			
			this.x=x;
			
		}
		
		
// Get X		
		
		public int getX() {
			return x;
		}
		
		
	// Set Y with parameter integer Y	
		
		public void setY(int y) {
			this.y=y;
		}
		
		
	// Get y	
		public int getY() {
			return y;
		}
		
		
		
	// Set depth with parameter integer depth
		
		
		public void setDepth(int depth) {
			this.depth=depth;
		}
		
		// get depth
		
		public int getDepth() {
			return depth;
		}
		
		// Set width with parameter integer width	
		
				public void setWidth(int width) {
					this.width=width;
				}
				
				
			// Get width	
				
				public int getWidth() {
					return width;
				}
				
		
		// To string
		
		public String toString()
		
		{
			String get = "Upper left: ("+ x +","+ y +"); "+width+" "+depth;
			
			return get;
		}

}
