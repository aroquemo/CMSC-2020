package application;


import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class ManagementCompanyTestSTUDENT {
	Property p1, p2, p3, p4, p5,p6;
	ManagementCompany m; 
	@Before
	public void setUp() throws Exception {
		
		
		
		p1 = new Property ("Cool place", "Rockville", 1000, "Honey Smith", 8, 6, 4, 2);
		p2 = new Property ("Ambiance", "Olney", 2000, "Tom Brady", 2, 4, 6, 8);
		p3 = new Property ("Cool place part 2", "Gaithersburg", 3000, "Drew Bress",3, 6, 9, 12);
		
		m = new ManagementCompany("Peyton", "123456789", 2);
	 
		m.addProperty(p1);
		m.addProperty(p2);
		m.addProperty(p3);
	}

	@After
	public void tearDown() {
		
		m = null;
	}

	@Test
	public void testAddPropertyDefaultPlot() {
		
		p4 = new Property("Four", "germantown", 4000, "Ariel Roque");
		
		p5 = new Property("Eight", "wheaton", 5000, "Jackson 5", 2,4,6, 8);
		
		p6 = new Property("too Many Props", "frederick", 6000, "cool" ,6,9,12, 3);
		
		assertEquals(m.addProperty(p4),3,0);
		
		assertEquals(m.addProperty(p5),4,0);
		
		assertEquals(m.addProperty(p6),-1,0);  
	}
 
	@Test
	public void testMaxRentProp() {
		//fail("STUDENT test not implemented yet");
		//student should test if maxRentProp contains the maximum rent of properties
		String maxRentString = m.maxRentProp().split("\n")[3];
		assertTrue(maxRentString.contains("5000.0"));
	}

	@Test
	public void testTotalRent() {
		//fail("STUDENT test not implemented yet");
		//student should test if totalRent returns the total rent of properties
		assertEquals(m.totalRent(),9100.0,0);
	}

 }
