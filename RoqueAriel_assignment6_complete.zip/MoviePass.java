// Programmer Ariel Roque
// CMSC 203
// ASsignment 6



package application;


import java.util.ArrayList;


public class MoviePass extends Ticket {

	// All variables to give ticket price info

	private static double beforeSix = 10.50;
	
	private static double afterSix = 3.5;
	
	private static double imaxTax = 3.0;
	
	private static double threeDBump = 2.5;
	
	private static double taxAmount = 0.096;
	
	
	private ArrayList<Ticket> price = new ArrayList<Ticket>();

	
	public MoviePass() {}

	// contrsuctor to set info for movies
	
	public MoviePass(String Name, int Day, int Time, String type, String tt, String Rating, int ID, ArrayList<Ticket> Tickets) {
		
		super();
		
		setName(Name);
		
		setRating(Rating);
		
		setDay(Day);
		
		setTime(Time);
		
		setMovieType(type);
		
		setTicketType("MoviePass");
		
		setId(ID);
		
		price = Tickets;
	}

	// check number of movies today
	
	public int numMoviesToday(int id, int day) {
		
		int currentDay = 0;

		
		for (int x = 0; x < price.size(); x++) {
			
			Ticket t = price.get(x);

			
			if (t.getId() == id && t.getDay() == day) 
			{ 
				currentDay++; 
				
			}
		}

		
		return currentDay;
	}

	
	// check numbers of specific movie
	
	public int numThisMovie(int id, String movie) {
		
		int m = 0;

		
		for (int x = 0; x < price.size(); x++) {
		
			Ticket one = price.get(x);

			
			if (one.getId() == id && one.getName().toLowerCase().equals(movie.toLowerCase())) { m++; }
		}

		
		return m;
	}

	
	// calculate total ticket price
	
	public double calculateTicketPrice() {
		
		double total = 10.50;
		
	
		if (getTime() >= 8 && getTime() < 18)
		{ 
			
			total += afterSix; 
		
		}
		
		if (getMovieType().equalsIgnoreCase("imax")) 
		{ 
			
			
			
			total += imaxTax; 
			
		}
		if (getMovieType().equalsIgnoreCase("3d"))
		{
			
			 total += threeDBump; 
			
			}


		return total;
	}
}