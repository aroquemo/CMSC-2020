//  Programmer: Ariel Roque
// CMSC 203
// Assignmnet 6




package application;

import java.util.ArrayList;


public class Employee extends Ticket {
	
	private static double beforeSix = 10.50;
	
	private static double afterSix = 3.5;
	
	private static double IMAX = 3.0;
	
	private static double DBump = 2.5;
	
	private static double tax = 0.096;
	
	private ArrayList<Ticket> prices = new ArrayList<Ticket>();

	
	public Employee() {}

	
	public Employee(String Name, int Time, int Day, String MovieType, String TicketType, String Rating, int ID, ArrayList<Ticket> Tickets) {
		
		super();
		
		
		setName(Name);
		
		
		setRating(Rating);
		
		
		setDay(Day);
		
		
		setTime(Time);
		
		setMovieType(MovieType);
		
		setTicketType("Employee");
		
		setId(ID);
		
		prices = Tickets;
	}

	
	public int numMoviesToday(int id, int day) {
		
		int moviesCurrent = 0;

		
		for (int x = 0; x < prices.size(); x++) {
			
			Ticket ticket = prices.get(x);

		
			if (ticket.getId() == id && ticket.getDay() == day)
			{ 
				moviesCurrent++; 
				
			}
		}

		
		return moviesCurrent;
	}

	
	public double calculateTicketPrice() {


		
		
		int  total = this.numMoviesToday(getId(), getDay());

		// Checks
		if (getTime() >= 18) 
		{
			total += afterSix; 
			
		}
		if (getMovieType().equalsIgnoreCase("imax")) 
		{
			total += IMAX;
			
		}
		if (getMovieType().equalsIgnoreCase("3d"))
{ 
			total += DBump;
			
}

		return total <= 2 ? 0.00 : (total / 2) + (total * tax);
	}
}