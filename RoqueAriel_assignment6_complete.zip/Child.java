//  Programmer: Ariel Roque
// CMSC 203
// Assignmnet 6





package application;

public class Child extends Ticket {
	
	private static double beforeSix = 5.75;
	
	private static double afterSix = 5.0;
	
	private static double IMAX = 2.0;
	
	private static double DBump = 1.5;
	
	private static double tax = 0.096;

	
	public Child() {}

	
	public Child(String Name, int Time, int Day, String MovieType, String TicketType, String Rating, int ID) {
		
		super();
		
		setName(Name);
		
		setRating(Rating);
		

		setDay(Day);
		

		setTime(Time);
		
		setMovieType(MovieType);
		
		setTicketType("Child");
		
		setId(ID);
	}

	
	public double calculateTicketPrice() {
		
		double total = beforeSix;

		
		if (this.getTime() >= 18)
		{ 
			total += afterSix; 
			
		}
		if (getMovieType().equalsIgnoreCase("imax"))
		{ 
			total += IMAX;
			
		}
		if (getMovieType().equalsIgnoreCase("3D"))
		{
			
			total += DBump; 
			
		
		}

	
		return total + (total * tax);
	}
}