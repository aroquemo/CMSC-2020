// Programmer Ariel Roque
// CMSC 203
// ASsignment 6


package application;



import java.math.BigDecimal;




public abstract class Ticket {
	
	private String name = "";
	
	private int time;
	
	private int day;
	
	private int id;
	
	private String type = "";
	
	private String tickets = "";
	
	private String rating = "";

	
	public Ticket() {}

	
	public Ticket(String Name, int Time, int Day, String type, String tt, String Rating, int ID) {
		
		this.setName(Name);
		
		this.setRating(Rating);
		
		this.setDay(Day);
		
		this.setTime(Time);
		
		this.setMovieType(type);
		
		this.setTicketType(tt);
		
		
		this.setId(ID);
	}

	// classes in order to set names.
	
	public double calculateTicketPrice() 
	{
		
		return 0;
	}

	
	public void setName(String name)
	{
		
		this.name = name;
		
	}

	
	public void setRating(String rating) 
	{
		
		rating = rating.toUpperCase();
		
	}

	
	public void setDay(int day) 
	{
		
		this.day = day;
		
	}

	
	public void setTime(int time) 
	{
		
		this.time = time;
		
	}

	
	public void setMovieType(String movietype) 
	{
		
		type = movietype;
		
	}

	
	public void setTicketType(String tickettype) 
	{
		
		tickets = tickettype;
		
	}

	
	public void setId(int id) 
	{
		
		this.id = id;
		
	}

	
	public String getName() 
	{
		
		return name;
		
	}

	
	public int getTime() 
	{
		
		return time;
		
	}

	
	public int getDay() 
	{
		return day;
	}

	
	public String getMovieType() 
	{
		return type;
	}

	
	public String getTicketType() 
	{
		return tickets;
	}

	
	public String getMovierating() 
	{
		return rating;
	}

	
	public int getId()
	{
		return type.equalsIgnoreCase("adult") || type.toLowerCase().equals("child") ? -1 : this.id;
	}

	
	public String toString()
	{
		
		String back = "";

	
		back += name;
		
		back += ":" + rating;
		
		back +=  ":" + type;
		
		back += ":" + tickets;
		
		back += ": #" + getId();
		
		back += ": $" + (new BigDecimal(this.calculateTicketPrice()).setScale(2, BigDecimal.ROUND_HALF_UP)).doubleValue();
		
		return back;
	}
}