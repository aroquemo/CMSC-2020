//  Programmer: Ariel Roque
// CMSC 203
// Assignmnet 6


package application;

public class Adult extends Ticket {
	
	private static double beforeSix = 10.50;
	
	private static double afterSix = 13.5;
	
	private static double imaxBump = 3.0;
	
	private static double dBump = 2.50;
	
	private static double tax = 0.096;

	
	public Adult() {}

	
	public Adult(String Name, int Time, int Day, String MovieType, String TicketType, String Rating, int ID) {
		
		super();
		
		setName(Name);
		
		setRating(Rating);
		
		setDay(Day);
		
		setTime(Time);
		
		setMovieType(MovieType);
		
		setTicketType("Adult");
		
		setId(ID);
	}

	
	public double calculateTicketPrice() {
		
		double total = beforeSix;

		if (this.getTime() >= 18) 
		{ 
			total += afterSix;
			
		}
		
		if (getMovieType().equalsIgnoreCase("imax"))
		
		{ 
			total += imaxBump;
			
		}
		if (getMovieType().equalsIgnoreCase("3d")) 
		
		{ 
			total += dBump;
			
		}

		
		return total + (total * tax);
	}
}