//  Programmer: Ariel Roque
// CMSC 203
// Assignmnet 6



package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.Collections;


//Imports
import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class MovieTicketManager implements MovieTicketManagerInterface {
	
	private ArrayList<Ticket> bought = new ArrayList<Ticket>();

	
	public MovieTicketManager() {}

	
	/** 
	 * Switch statement would not function properly, had to use if else statements in order to check type of ticket.
	 */
	
	// Add tickets
	
	@Override
	public double addTicket(String movieN, String rating, int day, int time, String f, String type, int id) {
		
		Ticket ticket = null;
		double total = 0;

		// else if statements to check type of movie ticket
		
				if (type.equalsIgnoreCase("adult")) 
				{
					ticket = new Adult(movieN, time, day, f, type, rating, id);
					
				total = ticket.calculateTicketPrice();
				
				} 
				else if (type.equalsIgnoreCase("child"))
				{
					ticket = new Child(movieN, time, day, f, type, rating, id);
					
					total = ticket.calculateTicketPrice();
					
				} 
				
				else if (type.equalsIgnoreCase("employee")) 
				{
					ticket = new Employee(movieN, time, day, f, type, rating, id, bought);
					
					total = ticket.calculateTicketPrice();
					
				}
				
				
				else if (type.equalsIgnoreCase("moviepass"))
				{
					ticket = new MoviePass(movieN, time, day, f, type, rating, id, bought);
					
					total = ticket.calculateTicketPrice();
				
				}
				

				// return ticket prices total
				
				
				bought.add(ticket);
				
				return (new BigDecimal(total)).doubleValue();
			}
	
	@Override
	// Array list to get 3D tickets
	
	public ArrayList<String> get3DTickets() 
	
	{
		
		ArrayList<String> DTickets = new ArrayList<String>();
		
		ArrayList<Ticket> type = this.sortTickets(1);

		// for loop
		
		for (int x = 0; x < type.size(); x++) 
		
		{
			
			Ticket t = type.get(x);

			// Nested if statement
			if (t.getMovieType().equals("3D"))
			{ 
				DTickets.add("Today's date " + t.getDay() + " " + t.toString());
				
			}
		}


		return DTickets;
	}
	
	
	// array list to get all types of tickets
	
	@Override
	public ArrayList<String> getAllTickets() {
		
		ArrayList<String> Alltickets = new ArrayList<String>();
		
		ArrayList<Ticket> t = this.sortTickets(1);

		
		for (int x = 0; x < t.size(); x++)
		{
			
			Alltickets.add("Todya's Date " + t.get(x).getDay() + " " + t.get(x).toString());
			
		}

		
		return Alltickets;
	}
	
	// array list to get movie pass tickets
	
	@Override
	public ArrayList<String> getMoviePassTickets() {
		
		ArrayList<String> pass = new ArrayList<String>();
		
		ArrayList<Ticket> sort = sortTickets(2);

		
		for (int x = 0; x < sort.size(); x++) {
			
			Ticket t = sort.get(x);

		
			if (t.getTicketType().equalsIgnoreCase("moviepass")) 
			{ 
				
				pass.add("Day: " + t.getDay() + " " + t.toString());
				
			}
		}

	
		return pass;
	}
	
	// public class to get Monthly sales report
	
	@Override
	public String monthlySalesReport() {
	
		String report;

		
		report = "Monthly Sales Report";
		
		report += "Sales\n";
		
		report += "ADULT Sales: "+ getTicketSalesCount("adult") +" $" + this.getTotalTicketSales("adult") + "\n";
		
		report += "CHILD Sales: "+ getTicketSalesCount("child") +" $" + this.getTotalTicketSales("child") + "\n";
		
		report += "EMPLOYEE Sales: "+ getTicketSalesCount("EMPLOYEE") +" $" + this.getTotalTicketSales("EMPLOYEE") + "\n";
		
		report += "MOVIEPASS Sales: "+ getTicketSalesCount("MOVIEPASS") +" $" + this.getTotalTicketSales("MOVIEPASS") + "\n";

		// Return
		return report;
	}

	@Override
	
	// public int to get number of movies current day
	
	public int numMoviesToday(int id, int day) {
	
		int current = 0;

	
		for (int x = 0; x < bought.size(); x++) {
			
			Ticket ticket = bought.get(x);

			
			if (ticket.getId() == id && ticket.getDay() == day) 
			{ 
				
				current++;
				
			}
		}

		return current;
	}

	// public int to get specific movie
	
	@Override
	public int numThisMovie(int id, String movie) {
		
		int m = 0;

		
		for (int x = 0; x < bought.size(); x++)
		{
			
			Ticket ticket = bought.get(x);

		
			if (ticket.getId() == id && ticket.getName().equals(movie.toLowerCase())) 
			{ 
				m++; 
				
			}
		}


		return m;
	}

	// track number of visits
	
	@Override
	public int numVisits(int id) {
		
		int numOfVisits = 0;

		// loop
		
		for (int v = 0; v < bought.size(); v++) 
		{
			
			Ticket ticket = bought.get(v);

			// nested if statement
			
			if (ticket.getId() == id) 
			{ 
				numOfVisits++; 
				
			}
		}

		return numOfVisits;
	}
	
	// read file to get all movie info

	@Override
	public void readFile(File file) throws FileNotFoundException {
		
		Scanner scan = new Scanner(file);

		
		while (scan.hasNextLine())
		{
			
			String Next = scan.nextLine();
			
			String movieSpecs[] = Next.trim().split(":");
			
			String movieName = movieSpecs[0];
			
			String movieRating = movieSpecs[1];
			
			int day = Integer.parseInt(movieSpecs[2]);
			
			int hour = Integer.parseInt(movieSpecs[3]);
			
			String genre = movieSpecs[4];
			
			String type = movieSpecs[5];
			
			int id = Integer.parseInt(movieSpecs[6]);
			

			
			addTicket(movieName, movieRating, day, hour, genre, type, id);
			
		}

		
		scan.close();
	}

	
	
	
	// sorting day and ID

	
	public ArrayList<Ticket> sortTickets(int dayID) 
	
	{
		
		ArrayList<Ticket> tickets = new ArrayList<Ticket>();

		for (int x = 0; x < bought.size(); x++) 
		{
			tickets.add(bought.get(x));
		}
		
		

		switch (dayID)
		{
	
		case 1: Collections.sort(tickets, new Comparator<Ticket>()
	
		{
		
			@Override
		
		public int compare(Ticket x, Ticket y) 
		{
			
			return x.getDay() - y.getDay();
			
		}
		
	});
		
	break;
	
	default:
		Collections.sort(tickets, new Comparator<Ticket>()
		{
			@Override
			public int compare(Ticket a, Ticket b) 
			{
				
				return a.getDay() - b.getDay();
				
			}
			
		});
		
	
	
}
		
		
		
		return tickets;
	}

	
// Ticket Sales count
	
	private int getTicketSalesCount(String type) {
		
		int total = 0;

		
		for (int x = 0; x < bought.size(); x++)
		{
			
			Ticket t = bought.get(x);

			
			if (t.getTicketType().equals(type.toLowerCase())) 
			{ 
				total++; 
				
			}
		}

		
		return total;
	}

	// gets total ticket sales
	
	private double getTotalTicketSales(String type) {
		
		double ticketSales = 0;

		
		for (int x = 0; x < bought.size(); x++)
		{
		
			Ticket ticket = bought.get(x);

			
			 ticketSales += ticket.calculateTicketPrice();
		}

		
		return ticketSales;
	}
	
	
	// Finds total sales for the month
	
	@Override
	public double totalSalesMonth()
	{
		
		double sales = 0;

		for (int x = 0; x < bought.size(); x++) 
		{
			
			Ticket ticket = bought.get(x);
			
			sales += ticket.calculateTicketPrice();
		}

	
		return sales;
	}
	
}



