package application;


	import static org.junit.Assert.*;

	import java.io.File;
	import java.io.FileNotFoundException;
	import java.io.PrintWriter;
	import java.util.ArrayList;
	import java.util.Scanner;

	import org.junit.After;
	import org.junit.Before;
	import org.junit.Test;

	public class MovieTicketManagerStudent {
		private MovieTicketManager ticketList;
		

		@Before
		public void setUp() throws Exception {
			ticketList = new MovieTicketManager();
			
			//Student add adult tickets
			ticketList.addTicket("Deadpool", "R", 4, 11, "NONE", "Adult", 0);
			//Student add children tickets
			ticketList.addTicket("end game", "PG-13", 3, 8, "NONE", "Child", 0);
			//Student add employee tickets
			ticketList.addTicket("guardians of the galaxy", "PG-13", 2, 9, "3D", "Employee", 12345);
			//Student add MoviePass member tickets
			ticketList.addTicket("Spider-man", "Pg-13", 1, 10, "NONE", "MoviePass", 22222);
		}


		/**
		 * Student Test the number of visits to the theater within the month
		 * This only applied to those who have id members - Employees or MoviePass members
		 */
		@Test
		public void testNumVisits() {
			fail("testNumVisits not implemented yet");
			//Student test Employees' number of visits
			assertEquals(0, ticketList.numVisits(12345));
			assertEquals(1, ticketList.numVisits(67891));
			//Student test MoviePass members' number of visits
			assertEquals(0, ticketList.numVisits(1231));
			assertEquals(1, ticketList.numVisits(32845));
		}

		/**
		 * Student Test the number of times this movie has been viewed
		 * This only applied to those who have id numbers - Employees or MoviePass members
		 */
		@Test
		public void testNumThisMovie() {
			fail("testNumThisMovie not implemented yet");
			//Student test Employees' number of views
			assertEquals(0, ticketList.numThisMovie(12345, "Deadpool"));
			assertEquals(1, ticketList.numThisMovie(67891, "SGuardians of the galaxy"));
			//Student test MoviePass members' number of views
			assertEquals(0, ticketList.numThisMovie(1231, "End game"));
			assertEquals(1, ticketList.numThisMovie(32845, "Spider-man"));
		}

	}