
public class Television {

	private String MANUFACTURER; // Manufacturer brand name
	
	
	private int SCREEN_SIZE; // Screen Size
	
	private boolean powerOn; // Power on or off
	
	private int channel; // The channel the tv is on
	
	private int volume; // Volume level of TV
	
	// Constructor
	public Television(String brand,int ScreenSize ) {
		
			
		MANUFACTURER = brand;
		
		SCREEN_SIZE = ScreenSize;
		
		// power is set to off(false)
		
		powerOn = false;

		// Volume is set to 20
		
		volume = 20;
		
		// Channel set to 2
		
		channel = 2;
		
	
		
	}
	
	// Accessor to return volume level
	
	public int getVolume() {
	
		return volume;
	}
	
	public int getSecondVolume() {
		
		return volume;
	}
	// Accessor method to return Channel
	
	public int getChannel() {
	
		return channel;
	}
	
	// Accessor Method to return manufacturer brand name
	
	public String getManufacturer() {
	
		
		return MANUFACTURER;
		
	}
	
	// Accessor Method to return size of television screen
	
	public int getScreenSize() {
	
	return SCREEN_SIZE;	
	
	}

 public int  getSecondSize() {
	 
	 return SCREEN_SIZE;
 }
 
 public int getSecondChannel() {
	 
	 return channel;
 }
 
 
 public String getSecondManu() {
	 
	 return MANUFACTURER; 
 }
 
 
 public void setSecondChannel(int signal) {
	 
	 channel = signal;
	
 }
 
// mutator method to set channel number	

 public void setChannel(int station) {
	 
	 channel = station;
	 
 }

 
 public void decreaseSecondV() {
	 
	 volume -= 2;
 }
 
 
// mutator method to determine if power is on or off	
 
		public void power() {
			
			powerOn = !powerOn;
 	
	}
		
		// mutator method  to increase volume by 1
		
		public void increaseVolume() {
		
			volume =+ 1;
			
		}
		
		// mutator method  to decrease volume by 1
		
		public void decreaseVolume() {
			
			volume -= 1;
		}

		public void powerOff () {
			
			powerOn = true;
		}

		
public static void main(String[] args) {
	
		
	
}
}