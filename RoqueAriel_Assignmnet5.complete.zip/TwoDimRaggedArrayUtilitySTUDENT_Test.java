package application;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TwoDimRaggedArrayUtilitySTUDENT_Test {
	//STUDENT fill in dataSetSTUDENT with values, it must be a ragged array
	  private double[][] dataSet1 = {{20, 40, 60}, {50, 30}, {10, 25, 30}};
	 
	  private double[][] dataSet2 = {{8.2, 6.2, 5.3, 4.8}, {7.9}, {1.1,8.7, 4.3}};

	private File inputFile,outputFile;

	@Before
	public void setUp() throws Exception {
		outputFile = new File("TestOut.txt");
	}

	@After
	public void tearDown() throws Exception {
		dataSet1 = null;
		
		dataSet2 = null;
		
		
		inputFile = outputFile = null;
	}

	/**
	 * Student Test getTotal method
	 * Return the total of all the elements in the two dimensional array
	 */
	@Test
	public void testGetTotal() {
		  assertEquals(265,TwoDimRaggedArrayUtility.getTotal(dataSet1),.001);
		  
		    assertEquals(46.5,TwoDimRaggedArrayUtility.getTotal(dataSet2),.001);
		    
		   	
		    
	}

	/**
	 * Student Test getAverage method
	 * Return the average of all the elements in the two dimensional array
	 */
	@Test
	public void testGetAverage() {
		 assertEquals(33.125,TwoDimRaggedArrayUtility.getAverage(dataSet1),.001);
		 
		    assertEquals(5.81,TwoDimRaggedArrayUtility.getAverage(dataSet2),.001);
		    
		 
	}

	/**
	 * Student Test getRowTotal method
	 * Return the total of all the elements of the row.
	 * Row 0 refers to the first row in the two dimensional array
	 */
	@Test
	public void testGetRowTotal() {
		assertEquals(120,TwoDimRaggedArrayUtility.getRowTotal(dataSet1,1),.001);
		
	    assertEquals(80,TwoDimRaggedArrayUtility.getRowTotal(dataSet1,2),.001);
	    
	    assertEquals(7.9,TwoDimRaggedArrayUtility.getRowTotal(dataSet2,0),.001);
	    
	    assertEquals(14.1,TwoDimRaggedArrayUtility.getRowTotal(dataSet2,2),.001);
	    
	
	}


	/**
	 * Student Test getColumnTotal method
	 * Return the total of all the elements in the column. If a row in the two dimensional array
	 * doesn't have this column index, it is not an error, it doesn't participate in this method.
	 * Column 0 refers to the first column in the two dimensional array
	 */
	@Test
	public void testGetColumnTotal() {
		  assertEquals(72.5,TwoDimRaggedArrayUtility.getColumnTotal(dataSet1,0),.001);
		  
		    assertEquals(100,TwoDimRaggedArrayUtility.getColumnTotal(dataSet1,2),.001);
		    
		    assertEquals(16.2,TwoDimRaggedArrayUtility.getColumnTotal(dataSet2,0),.001);
		    
		    assertEquals(11,TwoDimRaggedArrayUtility.getColumnTotal(dataSet2,3),.001);
			
	}


	/**
	 * Student Test getHighestInArray method
	 * Return the largest of all the elements in the two dimensional array.
	 */
	@Test
	public void testGetHighestInArray() {
		
		assertEquals(60,TwoDimRaggedArrayUtility.getAverage(dataSet1),.001);
		 
	    assertEquals(8.7,TwoDimRaggedArrayUtility.getAverage(dataSet2),.001);
			
	}
	

	/**
	 * Test the writeToFile method
	 * write the array to the outputFile File
	 * then read it back to make sure formatted correctly to read
	 * 
	 */
	@Test
	public void testWriteToFile() throws FileNotFoundException  {
		double[][] array=null;
		try {
			TwoDimRaggedArrayUtility.writeToFile(dataSet1, outputFile);
		} catch (Exception e) {
			fail("This should not have caused an Exception");
			
			array = TwoDimRaggedArrayUtility.readFile(outputFile);
		
		}
		
		assertEquals(20, array[0][0],.001);
		assertEquals(40, array[0][1],.001);
		assertEquals(60, array[0][2],.001);
		assertEquals(50, array[1][0],.001);
		assertEquals(30, array[1][1],.001);
		assertEquals(10, array[1][2],.001);
		assertEquals(25, array[1][3],.001);
		
	
	
	try {
		TwoDimRaggedArrayUtility.writeToFile(dataSet1, outputFile);
	} catch (Exception e) {
		fail("This should not have caused an Exception");
		
		fail("This should not have caused an Exception");
		
		array = TwoDimRaggedArrayUtility.readFile(outputFile);
	}
	
	assertEquals(8.2, array[0][0],.001);
	assertEquals(6.2, array[0][1],.001);
	assertEquals(5.3, array[0][2],.001);
	assertEquals(4.8, array[1][0],.001);
	assertEquals(7.9, array[1][1],.001);
	assertEquals(1.1, array[1][2],.001);
	assertEquals(8.7, array[1][3],.001);
	assertEquals(4.3, array[1][3],.001);
	
}
}

	

