// Programmer: Ariel Roque
// CMSC 203
// Assignment 5

package application;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class TwoDimRaggedArrayUtility {
	
	// read file
	
	/**
	pass in a file and return a two-dimensional ragged array of doubles
	 */
	public static double[][] readFile(File file) throws FileNotFoundException{

		int rows = 0;
		
		int column;
		
		String[][] data = new String[10][];
		Scanner next = new Scanner(file);
		
		while(next.hasNextLine())
		{
			
			data [rows] = next.nextLine().split(" ");
			rows++;
			
		}
		next.close();
		
		double i[][]= new double [rows][];
		
		for(int x =0 ; x < rows; x++){
			
			column = data [x].length;
			
			i[x] = new double [column];
			
			for(int col=0; col<data[x].length; col++){
				
				if(data[x][col]!=null)
				{
					i[x][col]=Double.parseDouble(data[x][col]);
					}
				}
			}
		return i;
	}
	
	
	// method writeToFile
	/**
	pass in a two-dimensional ragged array of doubles and a file, 
	and writes the ragged array into the file. 
	Each row is on a separate line and each double is separated by a space. 
	
	*/
	public static void writeToFile(double[][] data, File outputFile)throws FileNotFoundException  {
		
		PrintWriter output= new PrintWriter(outputFile);
		
		for (int numOfRows = 0; numOfRows < data.length; numOfRows++) 
		{
			for (int columns = 0; columns < data[numOfRows].length; columns++)
			{
					output.print(" " + data[numOfRows][columns]);
			
			}
			output.println();
		}
		output.close();
	}
	
	
	
	// for loop to retrieve total
	// I also try to keep the method variables different from each other because I end up conufsing myself.
	
	/**
	  pass in a two-dimensional ragged array of doubles 
	 and returns the total of the elements in the array.
	 
	 */
	public static double getTotal(double[][] data) {
		
		int total= 0;
		
		for(int totalNumRows = 0; totalNumRows < data.length; totalNumRows++)
		{
			for (int column = 0; column < data [totalNumRows].length; column++)
				
				total += data[totalNumRows][column];
			
		}
		return total;
	}
	
	
		// for loop to Retrieves average

	/**
	 pass in a two-dimensional ragged array of doubles
	  and returns the average of the elements in the array (total/num of elements).
	 */
	public static double getAverage(double[][] data) {
		double numOfElements = 0;
		double total = 0;
		
		for(int averageRows = 0; averageRows < data.length; averageRows++)
		{
			numOfElements += data[averageRows].length; 
		
		 for (int x = 0; x < data[averageRows].length; x++) 
		       total += data[averageRows][x];
		      }
		
		return total / numOfElements;
	}
	
	/// retrieve row total
	
	/**
	 pass in a two-dimensional ragged array of doubles and a row index 
	 and returns the total of that row. Row index 0 is the first row in the array.
	 */
	
	
	public static double getRowTotal(double[][] data, int row) 
	{
		double total = 0;
		
		for(int i = 0; i < data[row].length; i++)
		{
			total += data[row][i];
			
		}
		return total;
	}
	
	
	
	// retrieve column total
	
	/**
	 pass in a two-dimensional ragged array of doubles and a column index 
	 and returns the total of that column. Column index 0 is the first column in the array. 
	 If a row doesn�t contain that column, 
	 it is not an error, that row will not participate in this method.
	 */
	
	public static double getColumnTotal(double[][] data, int col) {
		double totalNumCol = 0;
		
		for(int column = 0; column < data.length; column++) 
		{
			if (data[column].length <= col)
				
			totalNumCol += data[column][col];
		}
		
		return totalNumCol;
	}
	
	
	
	
	// retrieve highest number that user inputs in row
	
	/**
	pass in a two-dimensional ragged array of doubles and a row index 
	and returns the largest element in that row. 
	Row index 0 is the first row in the array.
	 */
	public static double getHighestInRow(double[][] data, int row) 
	{
		double index = 0;
		double highestInRow = data[row][getHighestInRowIndex(data,row)];
		
		return highestInRow;
	}
	
	
	//  Identify highest number in row index
	
	/**
	  pass in a two-dimensional ragged array of doubles 
	  and a row index and returns the index of the largest element in that row. 
	  Row index 0 is the first row in the array.
	 */
	public static int getHighestInRowIndex(double[][] data, int row) {
		
		double highestInRowIndex = data[row][0];
		
		int index =0;
		
		
		for (int high = 0; high < data[row].length; high++) 
		{
			if(highestInRowIndex < data[row][high])
			{
				highestInRowIndex = data[row][high];
				
				index = high;
			}
		}
		
		return index;
	}
	
	
	// retrieve lowest user input in row
	
	/**
	 a two-dimensional ragged array of doubles and a row index 
	 and returns the smallest element in that row.
	  Row index 0 is the first row in the array.
	 */
	public static double getLowestInRow(double[][] data, int row)
	{
		
		double lowestInRow = data[row][getLowestInRowIndex(data,row)];
		
		return lowestInRow;
	}
	
	
	// retrieve lowest input index
	
	/**
	a two-dimensional ragged array of doubles and a row index and returns 
	the index of the smallest element in that row.
	 Row index 0 is the first row in the array.
	 */
	public static int getLowestInRowIndex(double[][] data, int row) {
		
		double lowestInRow = 0;
		int index =0;
		
		for (int lowest = 0; lowest < data[row].length; lowest++)
		{
			
			if(lowest > data[row][lowest])
			{
				lowestInRow = data[row][lowest];
				index = lowest ;
			}
		}
		return index;	
	}
	
	
	
	// get highest user input in column
	/**
	 pass in a two-dimensional ragged array of doubles 
	 and a column index and returns the largest element in that column. 
	 Column index 0 is the first column in the array. If a row doesn�t contain that column,
	  it is not an error, that row will not participate in this method.
	 */
	public static double getHighestInColumn(double[][] data, int col) 
	{
		
		
		return data[getHighestInColumnIndex(data, col)][col];
		
		
	}
	
	
	
	// retrieve highest user input index
	
	/**
	pass in a two-dimensional ragged array of doubles 
	and a column index and returns the index of the largest element in that column.
	 Column index 0 is the first column in the array. If a row doesn�t contain that column,
	 it is not an error, that row will not participate in this method.
	 */
	public static int getHighestInColumnIndex(double[][] data, int col) {
		
		
		int index = 0;
		
		double highestInColumn = 0;
		
		for(int highest = 0; highest< data.length; highest++)
		{
			if (data[highest].length <= col)
				
			if(highestInColumn < data[highest][col]) 
			{
				highestInColumn = data[highest][col];
				
				index = highest;
			}
		}
		return index;
	}
	
	// get lowest user input in column
	/**
	 pass in a two-dimensional ragged array of doubles 
	 and a column index and returns the smallest element in that column. 
	 Column index 0 is the first column in the array. If a row doesn�t contain that column, 
	 it is not an error, that row will not participate in this method.
	 */
	public static double getLowestInColumn(double[][] data, int col)
	{
		int index = 0;
		
		return data[getLowestInColumnIndex(data,col)][col];
		
	}
	
	
	// get the lowest user input in column
	
	/**
	 pass in a two-dimensional ragged array of doubles 
	 and a column index and returns the index of the smallest element in that column. Column index 0 is the first column in the array. If a row doesn�t contain that column,
	  it is not an error, that row will not participate in this method.
	 */
	
	public static int getLowestInColumnIndex(double[][] data, int col) {
		int index = -1;
		
		double lowest = 99999;
		
		for(int column = 0; column< data.length; column++)
		{
			if (data[column].length <= col)
				
				continue;
			
			if(lowest > data[column][col]) 
			{
				lowest = data[column][col];
				
				index = column;
			}
		}
		return index;
	}
	
	
	
	// return largest element in the array
	
	/**
	 pass in a two-dimensional ragged array of doubles 
	 and returns the largest element in the array.
	 */
	public static double getHighestInArray(double[][] data) 
	
	{
		double max = -99999;
		
		for(int m = 0; m < data.length; m++)
		
		{
			for (int col=0; col<data[m].length;col++)
				
				if (max < data[m][col])
					
					max = data[m][col];
		}
		
		return max;
	}
	
	
	// get lowest element in array
	
	
	/**
	pass in a two-dimensional ragged array of doubles 
	and returns the smallest element in the array.
	 */
	
	public static double getLowestInArray(double[][] data) 
	{
		double min = 999999;
		
		for(int m = 0; m <data.length; m++)
		{
		
			for (int i = 0; i < data[m].length; i++)
				
				if (min> data[m][i])
					
					min= data[m][i];
			}
		
		return min;
		}
}
