// Programmer: Ariel Roque
// CMSC 203
// Assignment 5


package application;

public class HolidayBonus {
	
	
	public HolidayBonus(){}
	
	// Method to calculate holiday bonus & passes 2D ragged arrays 
	
	public static double[] calculateHolidayBonus(double[][] data, double high, double low, double other )
	{
	
		double[] bonus = new double [data.length];
		
		for(int col = 0; col < data.length ; col++) 
		
		{
			{
				
					if(data[col][col] == data[TwoDimRaggedArrayUtility.getHighestInColumnIndex(data, col)][col])
						bonus[col]+=high;
		
					else if(data[col][col]== data[TwoDimRaggedArrayUtility.getLowestInColumnIndex(data, col)][col])
						bonus[col]+=low;
					
				
				}
			}
		return bonus;
	}

	
	
	public static double calculateTotalHolidayBonus(double[][] data, double high, double low, double other ){
		
		// Variables listed as doubles
		
		double total = 0;
		
		double[] holidayBonus = calculateHolidayBonus(data,high,low,other);
	
		// loop to help calculate holiday bonus total
		
		for(int x = 0; x < data.length; x++)
		{
			
			total += holidayBonus[x];
		}
		
		//returns total of holiday bonus
		
		return total;   
	}
	
}
