package application;

public class SavingsAccount extends BankAccount {
	//  Variables
	
	// rate
	private double rate = 0.025;
	private int savingsNumber = 0;
	private String accountNumber;

	
	public SavingsAccount(String N, double B) {
		
		super(N, B);
		this.accountNumber = super.getAccountNumber();
		this.setAccountNumber(this.accountNumber);
	}

	
	public SavingsAccount(BankAccount A, double B) {
		
		super(A, B);
		this.savingsNumber++;
		this.accountNumber = super.getAccountNumber();
		this.setAccountNumber(this.accountNumber);
	}


	
	public void postInterest() {
		this.setBalance((this.getBalance() * this.rate) + this.getBalance());
	}

	
	public String getAccountNumber()
	{
		return this.accountNumber + "-" + savingsNumber;
	}
}