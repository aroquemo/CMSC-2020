package application;

public class CheckingAccount extends BankAccount {
	// Class Variables
	private double FEE = 0.15;
	private String accountNumber;

	public CheckingAccount(String N, double B) {
		// Initialize BankAccount
		super(N, B);
		this.accountNumber = this.getAccountNumber() + "-10";
		this.setAccountNumber(this.accountNumber);
	}

	
	public boolean withdraw(double A) {
		
		if (A > this.getBalance()) { return false; }
		if (A + (this.FEE) > this.getBalance()) { return false; }

	
		boolean result = super.withdraw(A + (this.FEE));


		return result;
	}
}