package application;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class GradebookTester {
	private Gradebook gradebook1;
	private Gradebook gradebook2;
	
	@Before
	public void setUp() {
		// Initialize gradebooks
		gradebook1 = new Gradebook(2);
	
		
		// Add scores
		gradebook1.addScore(80);
		gradebook1.addScore(90);
		
	}

	@After
	public void tearDown()
	{
		gradebook1 = null;
		
	}

	@Test
	public void AddScore() 
	{
		String expectedScores1 = "80, 90";
		String actualScores1 = gradebook1.toString();
			
	}

	@Test
	public void testSum() {
		double expectedSum1 = 170;
		double actualSum1 = gradebook1.sum();
		
		assertTrue(expectedSum1 == actualSum1);
	}

	@Test
	public void testMinimum() 
	{
		double expectedMinimum1 = 80;
		
		double actualMinimum1 = gradebook1.minimum();
		
		assertTrue(expectedMinimum1 == actualMinimum1);
		
	}

	@Test
	public void testFinalScore() {
		double expectedScore1 = 90;
		double actualScore1 = gradebook1.finalScore();
		
		assertTrue(expectedScore1 == actualScore1);
		
	}


}
