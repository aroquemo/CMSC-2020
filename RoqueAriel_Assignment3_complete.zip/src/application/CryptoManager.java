// Programmer: Ariel Roque-Morales
// Program is suppsoed to use caesar and bellaso ciphers to encrypt and cecrypt user input words and phrases
// Class 203 (T/TR 2-3:40) 
// 10/17/2020



package application;

public class CryptoManager {
	
	private static final char LOWER_BOUND = ' ';
	private static final char UPPER_BOUND = '_';
	private static final int RANGE = UPPER_BOUND - LOWER_BOUND + 1;

	/**
	 * This method determines if a string is within the allowable bounds of ASCII codes 
	 * according to the LOWER_BOUND and UPPER_BOUND characters
	 * @param plainText a string to be encrypted, if it is within the allowable bounds
	 * @return true if all characters are within the allowable bounds, false if any character is outside
	 */
	
	// Set in bounds and rules for the plan text
	
	public static boolean stringInBounds (String plainText) {
		
		
		for (int t = 0; t < plainText.length(); t++) {
			
			if (plainText.charAt(t) < LOWER_BOUND || plainText.charAt(t) > UPPER_BOUND)
	
				return false;
		}
		
		return true;
	}

	/**
	 * Encrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in plainText is replaced by the character \"offset\" away from it 
	 * @param plainText an uppercase string to be encrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the encrypted string
	 */
	
	// Caesar encryption 
	
	public static String encryptCaesar(String plainText, int key) {
				
		
		
		if( key > UPPER_BOUND)
				{
			
			
			key = key - RANGE;
			
				}
				
				char [] encryptCC = new char [plainText.length()];
				
				for (int k = 0; k < plainText.length(); k++) {
					
					encryptCC[k]=(char)(plainText.charAt(k)+key);
					
					
					
					if(encryptCC [k] < LOWER_BOUND)
						
						encryptCC [k] += RANGE;
					
				}
				
				String encryptString = new String(encryptCC);
				
				return encryptString;
			}
	
	
	
	
	
	/**
	 * Encrypts a string according the Bellaso Cipher.  Each character in plainText is offset 
	 * according to the ASCII value of the corresponding character in bellasoStr, which is repeated
	 * to correspond to the length of plainText
	 * @param plainText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the encrypted string
	 */
	
	// Encryption for bellaso
	
	public static String encryptBellaso(String plainText, String bellasoStr) {
		
		// creating while loop to initiate bellaso cipher
				
				while(plainText.length() > bellasoStr.length()) {
					
					bellasoStr += bellasoStr;
				}
				
				char [] encrpytB = new char[plainText.length()];
			
				
				
				for (int k = 0; k < plainText.length();k++) {
				
					
					
					encrpytB [k]= (char) (plainText.charAt(k)+bellasoStr.charAt (k)-RANGE);		
				
					
					
			// if statement to verify is encryptB k	is greater than upper bound to subtract from the range	
					
				
					// If statement to verify is encryptB is less than lower bound to add to range	
					
					if ( encrpytB [k] < LOWER_BOUND)
						
						encrpytB  [k] += RANGE;
					
				}
				
				String encryptString = new String(encrpytB);
				
				
				
				return encryptString;
			}

	
	/**
	 * Decrypts a string according to the Caesar Cipher.  The integer key specifies an offset
	 * and each character in encryptedText is replaced by the character \"offset\" characters before it.
	 * This is the inverse of the encryptCaesar method.
	 * @param encryptedText an encrypted string to be decrypted.
	 * @param key an integer that specifies the offset of each character
	 * @return the plain text string
	 */
	
	
	// Decrypt for Caesar
	
	public static String decryptCaesar(String encryptedText, int key) {
		
		
		
		// if statement with nest while loop to verify is key is less than upper bound		
		
		
				if ( key > UPPER_BOUND)
				{
					
					do {
						
						key-=RANGE;
					}
					
					while( key > UPPER_BOUND);
					
					// if statement to verify key is less than range and subtract key - range		
					
				
		
				}
				
				
				
				char[] decryptCC = new char [encryptedText.length()];
				
				for (int k = 0; k <encryptedText.length();k++) {
				
				
					
					decryptCC[k]=(char)(encryptedText.charAt(k)-key);
					
				
					
					if(decryptCC [k] > UPPER_BOUND)
				
						
						decryptCC [k] -= RANGE;
					
		
					
					if(decryptCC [k] < LOWER_BOUND)
	
						decryptCC [k] += RANGE;
				}

				String decryptString = new String(decryptCC);
				
				//return decryptString
				
				return decryptString;
			}
	
	
	/**
	 * Decrypts a string according the Bellaso Cipher.  Each character in encryptedText is replaced by
	 * the character corresponding to the character in bellasoStr, which is repeated
	 * to correspond to the length of plainText.  This is the inverse of the encryptBellaso method.
	 * @param encryptedText an uppercase string to be encrypted.
	 * @param bellasoStr an uppercase string that specifies the offsets, character by character.
	 * @return the decrypted string
	 */
	
	// Decryption for bellaso test
	public static String decryptBellaso(String encryptedText, String bellasoStr) {
	
	
				
		while(encryptedText.length() > bellasoStr.length()) {
		
			
			bellasoStr += bellasoStr;
			
		}
		
		
		
		char[] decryptBC;
		
		char [] bellasoDecrypt;
		
	// Initializing char arrays
		
		decryptBC = encryptedText.toCharArray();
		
	
		
		bellasoDecrypt = bellasoStr.toCharArray();
		
		// For loop to check char length and to decide whether to add or subtract to range
		
		for (int t = 0; t < decryptBC.length; t++) {
		
		
			
			decryptBC [t] = (char) (( decryptBC [t] + RANGE) - bellasoDecrypt[t] );
			
			
	
			
			if( decryptBC[t] < LOWER_BOUND)
			
				
				decryptBC [t] += RANGE;
				
		}
		
		String decryptString = new String(decryptBC);
		
				
				
				// Return decryptString
		
		return decryptString;
			}
		
	}
