import java.util.Scanner;

public class MovieDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 String title;
		
		 String rating;
	
		 String response;
		
		 String ticketSold;
		
		Scanner keyboard = new Scanner (System.in);
		
		do{
		System.out.println("Enter the movie title: ");
		title = keyboard.nextLine();
		
		System.out.println("Enter the rating of the movie: ");
		
		rating = keyboard.nextLine();
		
		System.out.println("How many tickets were sold: ");
		
		ticketSold = keyboard.nextLine();
		
		System.out.println(title + " is rated " + rating + " and has sold " + ticketSold);
		
		System.out.println("Would you like to enter another movie?(y or n): ");
			response = keyboard.nextLine();
		}
		while(response.equals("y"));
	
	}

}
